﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;


namespace examination_system
{
    public partial class adminlog : Form
    {
        OracleConnection CON1;
        OracleCommand CMD;
        string QUERY;
        OracleDataReader RDR;
        OracleDataAdapter da;
        DataSet d;
        string username;
        public adminlog(string usr)
        {
            username = usr;
            InitializeComponent(); CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");
        }

        private void adminlog_Load(object sender, EventArgs e)
        { 
            QUERY = "select * from adminlog";
            CMD = new OracleCommand(QUERY, CON1);
            try
            {
                CON1.Open();
                da = new OracleDataAdapter(QUERY, CON1);
                d = new DataSet();
                da.Fill(d, "test");
                dataGridView1.DataSource = d.Tables[0];
                CON1.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
            finally
            {
                CON1.Close();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminhome a = new adminhome(username);
            this.Hide();
            a.Show();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
