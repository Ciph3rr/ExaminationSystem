﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Oracle.DataAccess.Client;
using System.IO;
namespace examination_system
{
    public partial class register : Form
    {
        string fac = "";

        int qno;string name;
        string imgp="";
        OracleConnection CON1;
        OracleCommand CMD;
        string state="";
        string QUERY;
        OracleDataReader RDR;
        public register(string usr)
        {
            InitializeComponent(); CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");fillcombo(); username = usr;
        }
        string username;
        
        public void fillcombo()
        {
            QUERY = "select * from SUBJECT";
           
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();

            RDR = CMD.ExecuteReader();

            while (RDR.Read())
            {
                name = (string)RDR["SUBJECTNAME"];
                comboBox1.Items.Add(name);
            }
            CON1.Close();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }
        public void newrecord()
        {
            string query2, id;
            query2 = "select max(SID) from STUDENTDETAILS";
            CON1.Open();
            CMD = new OracleCommand(query2, CON1);
            CMD.CommandText = query2;
            id = Convert.ToString(CMD.ExecuteScalar());
                int s;
            if (id.Equals(""))
            {
                s = Convert.ToInt16(1);
                qno = Convert.ToInt16(s);
            }
            else
            {
                s = (Convert.ToInt16(id) + 1);
                //MessageBox.Show (Convert.ToString(s));
                qno = s;
            }
            CON1.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            newrecord();
            textBox10.Text =Convert.ToString(qno);
            int size=0;
            size = textBox8.TextLength;
           // MessageBox.Show("mobile no length '" +size+"'");
            if (size < 10)
            {
                MessageBox.Show("Enter a valid phone number");
            }
            else if (textBox5.Text != textBox6.Text)
            {
                MessageBox.Show("Passwords do not match!", "MojoCRM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox5.Text =="" || textBox6.Text=="")
            {
                MessageBox.Show("Password field cannot be left blank!", "MojoCRM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox1.Text=="")
                {
                MessageBox.Show("First name is manditoary", "MojoCRM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("Last name is manditoary", "MojoCRM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox4.Text == "")
            {
                MessageBox.Show("Address is manditoary", "MojoCRM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(radioButton1.Checked==false&&radioButton2.Checked==false)
            {
                    MessageBox.Show("Select your gender", "MojoCRM", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
            }
             
            else
            {
                 if (radioButton1.Checked == true)
                {
                    state = "male";
                }
                 else
                {
                    state = "female";
                }
               
                Regex mRegxExpression;
                if (textBox9.Text.Trim() != string.Empty)
                {
                    mRegxExpression = new Regex(@"^([a-zA-Z0-9_\-])([a-zA-Z0-9_\-\.]*)@(\[((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}|((([a-zA-Z0-9\-]+)\.)+))([a-zA-Z]{2,}|(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\])$");
                    if (!mRegxExpression.IsMatch(textBox9.Text.Trim()))
                    {
                        MessageBox.Show("E-mail address format is not correct.", "MojoCRM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox9.Focus();
                    }
                    else
                    {
                        CON1.Open();
                        QUERY = "Select * from SUBJECT where SUBJECTNAME=( '" + comboBox1.Text + "' )";

                        CMD = new OracleCommand(QUERY, CON1);
                      //  CON1.Open();
                        RDR = CMD.ExecuteReader();

                        while (RDR.Read())
                        {
                            fac = (string)RDR["PROF"];
              //              MessageBox.Show(Convert.ToString(fac));
                        }
                        CON1.Close();




                        byte[] imageBt = null;
                        FileStream fstream = new FileStream(this.TextBox_image_path.Text,FileMode.Open,FileAccess.Read);
                        BinaryReader br = new BinaryReader(fstream);
                        imageBt = br.ReadBytes((int)fstream.Length);

                        int temp = 0;

                       
                        QUERY = "insert into studentdetails values ('" + qno + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + this.dateTimePicker1.Text + "','" +comboBox1.Text+ "','" + state + "','" + textBox8.Text + "','" + textBox9.Text + "','" + imgp + "','" + fac + "' )";
                       

                        CMD.Parameters.Add(new OracleParameter("IMG", imageBt));
            //            MessageBox.Show(QUERY);
                        CON1.Open();
                        CMD = new OracleCommand(QUERY, CON1);
                        temp = CMD.ExecuteNonQuery();
                        if (temp > 0)
                        {
                            
                            MessageBox.Show("YOU HAVE BEEN ADDED :D NOTE YOUR STUDENT ID");

                            /// Updateqno();
                        }
                        else
                        {
        //                    MessageBox.Show("failed");
                        }
                        QUERY = "INSERT INTO USER_LOGIN VALUES ('" + textBox1.Text + "','" + textBox5.Text + "','" + qno + "')";
                        CMD = new OracleCommand(QUERY, CON1);
                        CMD.ExecuteNonQuery();

                        DateTime datetime = DateTime.Now;
                        string activity = "CREATED AN ACCOUNT WITH ID = (" + qno + ")";
                        QUERY = "insert into studentlog values  ('" + textBox1.Text + "','" + datetime.ToString() + "','" + activity + "')";
                        CMD = new OracleCommand(QUERY, CON1);
                        CMD.ExecuteNonQuery();

                        CON1.Close();

                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog opnfd = new OpenFileDialog();
            opnfd.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg.*.gif";
            if (opnfd.ShowDialog() == DialogResult.OK)
            {
                string picpath = opnfd.FileName.ToString();
                //pictureBox1.Image = new Bitmap(opnfd.FileName);
                TextBox_image_path.Text = picpath;
                imgp = TextBox_image_path.Text;
                pictureBox1.ImageLocation = picpath;

            }
        
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void delete_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            loginpage ap = new loginpage();this.Hide();ap.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            comboBox1.Text = "";
 
        }
    }
}

