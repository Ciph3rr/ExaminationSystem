﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
    
    public partial class viewres : Form
    {
        string username;
        string QUERY; string name;
        OracleDataReader RDR;
        OracleConnection CON1;
        OracleCommand CMD;
        int marks=0;
        string q;
        public viewres(string usr,string q)
        {
            this.q = q;
            username = usr;
            InitializeComponent();
            CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");
          
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            mainpage a = new mainpage(username);
            this.Hide();
            a.Show();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void viewres_Load(object sender, EventArgs e)
        {
            QUERY = "select * from studentresults where username =('" + username + "') and subject= ('" + q + "')";
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();
            RDR = CMD.ExecuteReader();
            while (RDR.Read())
            {
                marks = Convert.ToInt16(RDR["MARKS"]);
                // FLAG = 1;
            }
            RDR.Close();
            CON1.Close();
            label3.Text = marks.ToString();
            label5.Text = q;
            DateTime datetime = DateTime.Now;
            string activity = "viewed result for (" + username + ") from subject: " + q + "";

            QUERY = "insert into studentlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();
            CMD.CommandType = CommandType.Text;
            CMD.ExecuteNonQuery();
            CON1.Close();
        }
    }
}
