﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace examination_system
{
    public partial class test : Form
    {
        string username;
        int sid ;
        int marks=0;
        private int answer;
        OracleConnection CON1;
 
        OracleCommand CMD;
        OracleCommand CMD2;
        string QUERY;
        string QUERY1;
        OracleDataReader RDR;
        OracleDataReader RDR2;
        int iter=0;
        string sub = "";
        public test(string str, string usr)
        {
            username = usr;
            //MessageBox.Show(username);

            sub = str;
            InitializeComponent();
            CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");
            load();
        }
        public void load()
        {
     
            QUERY1 = "select * from studentdetails where fname ='" + username + "'";
            
            CMD2 = new OracleCommand(QUERY1, CON1);
            CON1.Open();
           
            RDR2 = CMD2.ExecuteReader();
           
            while (RDR2.Read())
            {
                sid = Convert.ToInt16(RDR2["SID"]);
            }
            CON1.Close();
        }
        public void generate()
        {
            Random random = new Random();
            answer = random.Next(1, 10);
            MessageBox.Show(sub);
            string STR = ""; string OPT1 = ""; string OPT2 = ""; string OPT3 = ""; string copt = "";
            QUERY = "select * from "+sub+" where qno =('" + answer + "')";
            MessageBox.Show(QUERY);
            QUERY1 = "select * from studentdetails where fname ='" + username + "'";
            CMD = new OracleCommand(QUERY, CON1);
            CMD2 = new OracleCommand(QUERY1, CON1);
            CON1.Close();
            CON1.Open();
            RDR = CMD.ExecuteReader();
            RDR2 = CMD2.ExecuteReader();
            while (RDR.Read())
            {
                STR = (string)RDR["question"];
                OPT1 = (string)RDR["option1"];
                OPT2 = (string)RDR["option2"];
                OPT3 = (string)RDR["option3"];
                copt = (string)RDR["correct_option"];
                MessageBox.Show(STR);
                groupBox1.Text = STR;
                radioButton1.Text = OPT1;
                radioButton2.Text = OPT2;
                radioButton3.Text = OPT3;
            }
            
            while (RDR2.Read())
            {
              //  //MessageBox.Show();
               
             username = (string)RDR2["fname"];
                sid = Convert.ToInt16(RDR2["sid"]); 
            }
            
          
            string ans = "";
            if (radioButton1.Checked == true)
            {
                ans = radioButton1.Text;
            }
            else if (radioButton2.Checked == true)
            {
                ans = radioButton2.Text;
            }
            else
            {
                ans = radioButton3.Text;
            }

            if (ans == copt)
            {
                marks = marks + 5;
            }
            RDR.Close();

            CON1.Close();
        }

        private void test_Load(object sender, EventArgs e)
        {
            load();
            generate();
            iter = iter + 1;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (iter == 5)
            {
                MessageBox.Show("Test Complete! Brewing your results!!");
                this.Hide();
                MessageBox.Show("You scored '" +marks+ "'out of 50 ! ");
                mainpage m = new mainpage(username);
                this.Hide();
                m.Show();
                Random random = new Random();
               answer = random.Next(1, 10);
                int temp = 0;
                CON1.Open();
                int percntage;
                percntage = (marks / 50) * 100;

                QUERY = "select * from studentdetails where fname ='" +username + "' ";
                CMD = new OracleCommand(QUERY, CON1);
                //CON1.Open();
                RDR = CMD.ExecuteReader();
                while (RDR.Read())
                {
                    sid =Convert.ToInt16(RDR["SID"]);
                }
                RDR.Close();
                CON1.Close();

                CON1.Open();
                //MessageBox.Show(username);
                QUERY = "Insert into STUDENTRESULTS values('" +Convert.ToInt16(sid) + "','" + username + "','" + marks + "','" + sub + "')";
                //MessageBox.Show(QUERY);
                CMD = new OracleCommand(QUERY, CON1);
                temp = CMD.ExecuteNonQuery();
                if(temp>0)
                {
                    //MessageBox.Show("sucessfully pushed");
                    DateTime datetime = DateTime.Now;
                    string activity = "test taken by (" + username + ") in subject " + sub + "";
                    
                    QUERY = "insert into studentlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
                    CMD = new OracleCommand(QUERY, CON1);
                    //CON1.Open();
                    CMD.CommandType = CommandType.Text;
                    CMD.ExecuteNonQuery();
                    CON1.Close();
                }
                else
                {
                   // messageBox.Show("failed to pushed");
                }     
            }
            else
            {
                generate();
                iter = iter + 1;
            }CON1.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You scored '" + marks + "'out of 50 ! ");
            //MessageBox.Show(tempx);
            //Random random = new Random();
            //answer = random.Next(1, 10);
            int temp = 0;
           
            int percntage;
            percntage = (marks / 50) * 100;
            QUERY = "Insert into studentresults values('" + sid + "','" + username + "','" + marks + "')";
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();
            temp = CMD.ExecuteNonQuery();
            if (temp > 0)
            {
                //MessageBox.Show("sucessfully pushed");
                this.Hide();
                mainpage x = new mainpage(username);
                x.Show();
                
            }
            else
            {
                //MessageBox.Show("failed to pushed");
            }
            youquit q = new youquit();
         MessageBox.Show("Quitting results in failure of test!!");
            this.Hide();
            q.Show();
            CON1.Close();
        }
    }
}
