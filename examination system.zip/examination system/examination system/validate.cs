﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
    public partial class validate : Form
    {
        string QUERY,QUERY2,QUERY3; string name;
        OracleDataReader RDR;
        OracleConnection CON1;
        OracleCommand CMD;
        string username;
        public validate(string usr)
        {
            username = usr;
            InitializeComponent();
            CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");
            calculate();
        }
        int val;

        public void calculate()
        {
            QUERY = "select avg(marks)from RESULTS where FACULTY=('"+username+"')";
            CMD = new OracleCommand(QUERY, CON1);CON1.Open();
            CMD.CommandText = QUERY;
           label1.Text=(CMD.ExecuteScalar().ToString());
           
            QUERY2 = "SELECT MIN(MARKS)FROM RESULTS where FACULTY=('" + username + "')";
            CMD = new OracleCommand(QUERY2, CON1);
            CMD.CommandText = QUERY2;
            label6.Text= (CMD.ExecuteScalar().ToString());

            QUERY3 = "SELECT max(MARKS)FROM RESULTS where FACULTY=('" + username + "')";
            CMD = new OracleCommand(QUERY3, CON1);
            CMD.CommandText = QUERY3;
            label7.Text = (CMD.ExecuteScalar().ToString());


            DateTime datetime = DateTime.Now;
            string activity = "VIEWED CLASS PERFORMANCE ";
            MessageBox.Show(username);
            QUERY = "insert into adminlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
            CMD = new OracleCommand(QUERY, CON1);
            CMD.CommandType = CommandType.Text;
            CMD.ExecuteNonQuery();


            CON1.Close();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminhome mp = new adminhome(username);
            this.Hide();
            mp.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
