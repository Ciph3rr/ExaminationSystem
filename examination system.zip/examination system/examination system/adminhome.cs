﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace examination_system
{
    public partial class adminhome : Form
    {
        string usr;
        public adminhome(string username)
        {
            InitializeComponent();
            usr = username;
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void adminhome_Load(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            studentlog sl = new studentlog(usr);
            sl.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            adddelupdateq ad = new adddelupdateq(usr);
            this.Hide();
            ad.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminlog alog = new adminlog(usr);this.Hide(); alog.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            loginpage l = new loginpage();
            this.Hide();
            l.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            addupdatefac f = new addupdatefac(usr);
            this.Hide();
            f.Show();

        }

        private void button8_Click(object sender, EventArgs e)
        {
            findresult f = new findresult();
                this.Hide();
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            validate fd = new validate(usr);
            this.Hide(); 
            fd.Show();
        }
    }
}
