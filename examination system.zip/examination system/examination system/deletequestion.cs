﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
           
    public partial class deletequestion : Form
    {
        OracleConnection CON1;
        OracleCommand CMD;
        string QUERY; OracleDataAdapter da;
        DataSet d;
        string name;
        OracleDataReader RDR;
        string username;
        public deletequestion(string usr)
        {
            InitializeComponent();
            username = usr;
            CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");
            fillcombo();
        }
        //string choice = "";
        public void fillcombo()
        {
            QUERY = "select * from SUBJECT";

            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();

            RDR = CMD.ExecuteReader();

            while (RDR.Read())
            {
                name = (string)RDR["SUBJECTNAME"];
                comboBox1.Items.Add(name);
            }
            CON1.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || textBox1.Text == "")
            {
                MessageBox.Show("please enter all fields");
            }
            else
            {
                int temp = 0;
                QUERY = "delete from  " + comboBox1.Text + " where QNO = ('" + Convert.ToInt16(textBox1.Text) + "')";
                CMD = new OracleCommand(QUERY, CON1);
                CON1.Open();
                CMD.CommandType = CommandType.Text;
                //  MessageBox.Show(QUERY);
                temp = CMD.ExecuteNonQuery();
                if (temp > 0)
                {
                    MessageBox.Show("QUESTION DELETED SUCCESSFULLY!!");
                }
                else
                {
                    MessageBox.Show("VERIFY YOUR QUESTION NUMBER");
                }
                CON1.Close();
                DateTime datetime = DateTime.Now;
                string activity = "deleted a question (" + textBox1.Text + ") from subject: " + comboBox1.Text + "";
                MessageBox.Show(username);
                QUERY = "insert into adminlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
                CMD = new OracleCommand(QUERY, CON1);
                CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
                CON1.Close();
            }
        }
         
        

        private void button1_Click(object sender, EventArgs e)
        {
            adddelupdateq adq = new adddelupdateq(username);
            this.Hide();
            adq.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (comboBox1.Text != "C" && comboBox1.Text != "JAVA" && comboBox1.Text != "HTML" && comboBox1.Text == "")
            {
                MessageBox.Show("Please select a valid subject");
            }

            else
            {
                QUERY = "select * from  " + comboBox1.Text + "";
                CMD = new OracleCommand(QUERY, CON1);
                try
                {
                    CON1.Open();
                    da = new OracleDataAdapter(QUERY, CON1);
                    d = new DataSet();
                    da.Fill(d, "test");
                    dataGridView1.DataSource = d.Tables[0];
                    CON1.Close();
                }
                catch (Exception er)
                {
                    MessageBox.Show(er.Message);
                }
                finally
                {
                    CON1.Close();
                }
            }
        }

        private void deletequestion_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
