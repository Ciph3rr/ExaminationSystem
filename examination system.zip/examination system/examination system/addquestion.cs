﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
    public partial class addquestion : Form
    {
        int qno;
        string QUERY; string name;
        OracleDataReader RDR;
        OracleConnection CON1;
        OracleCommand CMD;
        string username;
        public addquestion(string usr)
        {
            username = usr;
            InitializeComponent();
            CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password "); fillcombo();
        }
        public void NEWRECORD()
        {
            string query2, id;
            query2 = "select max(QNO) from "+comboBox1.Text+"";
            CON1.Open();
            CMD = new OracleCommand(query2, CON1);
            CMD.CommandText = query2;
            id = Convert.ToString(CMD.ExecuteScalar());
            string s;
            int x;
            if (id.Equals(""))
            {
                s = Convert.ToString(1);
                qno = Convert.ToInt16(s);
            }
            else
            {

                x = (Convert.ToInt16(id) + 1);
              //  MessageBox.Show(Convert.ToString(s));
                qno = x;
            }
            CON1.Close();
        }
        public void fillcombo()
        {
            QUERY = "select * from SUBJECT";

            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();

            RDR = CMD.ExecuteReader();

            while (RDR.Read())
            {
                name = (string)RDR["SUBJECTNAME"];
                comboBox1.Items.Add(name);
            }
            CON1.Close();
        }
    
        public void Addquestion()
        {
            if(textBox1.Text=="" && textBox3.Text == "" && textBox3.Text == "" && textBox4.Text == "" && textBox5.Text == "" && comboBox1.Text == "")
            {
                MessageBox.Show("Fill Entire Form");
            }
            else
            { 
                NEWRECORD();
                QUERY = "insert into " + comboBox1.Text + " values  ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + qno + "')";
                CMD = new OracleCommand(QUERY, CON1);
                CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
                CON1.Close(); 
                 DateTime datetime = DateTime.Now;
                string activity = "added a question (" + qno + ") from subject: " + comboBox1.Text + "";
                MessageBox.Show(username);
                QUERY = "insert into adminlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
                CMD = new OracleCommand(QUERY, CON1);
                CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
                CON1.Close();
            }
      
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == textBox3.Text || textBox4.Text == textBox3.Text || textBox4.Text == textBox2.Text)
            {
                MessageBox.Show("OPTIONS REPEATED SEVERAL TIMES!");
            }
            else
            {
                DateTime datetime = DateTime.Now;
                string activity = "added a question (" + qno + ") in table " + comboBox1.Text + "";
                Addquestion();
                QUERY = "insert into adminlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
                CMD = new OracleCommand(QUERY, CON1);
                CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
                CON1.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == textBox3.Text || textBox4.Text == textBox3.Text || textBox4.Text == textBox2.Text)
            {
                MessageBox.Show("OPTIONS REPEATED SEVERAL TIMES!");
            }
            else
            {
                Addquestion();
                adddelupdateq al = new adddelupdateq(username);
                this.Hide();
                al.Show();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    
}
