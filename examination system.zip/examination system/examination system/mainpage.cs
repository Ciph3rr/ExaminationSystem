﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
    public partial class mainpage : Form
    {
        string QUERY; string name;
        OracleDataReader RDR;
        OracleConnection CON1;
        OracleCommand CMD;
        string username;
        public mainpage( string username)
        {
            this.username = username;
            InitializeComponent(); CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password "); fillcombo();
        
        }
        public void fillcombo()
        {
            QUERY = "select * from SUBJECT";

            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();

            RDR = CMD.ExecuteReader();

            while (RDR.Read())
            {
                name = (string)RDR["SUBJECTNAME"];
                comboBox1.Items.Add(name);
            }
            CON1.Close();
        }


        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "") { MessageBox.Show("select a subject"); }
            else
            {
                string x = comboBox1.Text;
                viewres vr = new viewres(username, x);
                this.Hide();
                vr.Show();
            }

           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.Text == "") { MessageBox.Show("select a subject"); }
            else
            {
                string str = comboBox1.Text;
                test tes = new test(str, username);
                this.Hide();
                tes.Show();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            loginpage l = new loginpage();this.Hide();l.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
