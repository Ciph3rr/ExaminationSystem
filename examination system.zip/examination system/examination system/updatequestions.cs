﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
    public partial class updatequestions : Form
    {
        string name;
        OracleDataReader RDR;
        OracleConnection CON1;
        OracleCommand CMD;
        string QUERY;
        OracleDataAdapter da;
        DataSet d;
        string username;
        public updatequestions(string usr)
        {
            InitializeComponent();
            username = usr;
            CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");fillcombo();
        }
        public void fillcombo()
        {
            QUERY = "select * from SUBJECT";

            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();

            RDR = CMD.ExecuteReader();

            while (RDR.Read())
            {
                name = (string)RDR["SUBJECTNAME"];
                comboBox1.Items.Add(name);
            }
            CON1.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void updatequestions_Load(object sender, EventArgs e)
        {
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "C" && comboBox1.Text != "JAVA" && comboBox1.Text != "HTML"&&comboBox1.Text=="")
            {
                MessageBox.Show("Please select a valid subject");
            }
           
            else
            {
                QUERY = "select * from  "+comboBox1.Text+"" ;
                CMD = new OracleCommand(QUERY, CON1);
                try
                {
                    CON1.Open();
                    da = new OracleDataAdapter(QUERY, CON1);
                    d = new DataSet();
                    da.Fill(d, "test");
                    dataGridView1.DataSource = d.Tables[0];
                    CON1.Close();
                }
                catch (Exception er)
                {
                    MessageBox.Show(er.Message);
                }
                finally
                {
                    CON1.Close();
                }
            }
        }
    
    private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text ="";
            textBox2.Text ="";
            textBox3.Text ="";
            textBox4.Text ="";
            textBox5.Text ="";
            textBox6.Text ="";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminhome ah = new adminhome(username);
            ah.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int temp = 0;
           QUERY = "update "+comboBox1.Text+" set qno='"+textBox1.Text+"',question='"+textBox2.Text+"',option1='"+textBox3.Text+"',option2='"+textBox4.Text+"',option3='"+textBox5.Text+"',correct_option='"+textBox6.Text+"' where qno="+textBox1.Text+"";
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();
            CMD.CommandType = CommandType.Text;
            temp=CMD.ExecuteNonQuery();
            if(temp>0)
            {
                MessageBox.Show("updated!!");
                DateTime datetime = DateTime.Now;
                string activity = "updated a question (" + textBox1.Text + ") from subject: " + comboBox1.Text + "";
              //  MessageBox.Show(username);
                QUERY = "insert into adminlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
                CMD = new OracleCommand(QUERY, CON1);
                //CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                comboBox1.Text = "";
            }
            else
            {
                MessageBox.Show("error");
            }
            CON1.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            adddelupdateq r = new adddelupdateq(username);this.Hide();r.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            comboBox1.Text = "";

        }
    }
}
//