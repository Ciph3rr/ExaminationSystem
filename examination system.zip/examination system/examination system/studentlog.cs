﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;


namespace examination_system
{

    public partial class studentlog : Form
    {
        string username;
        OracleConnection CON1;
        OracleCommand CMD;
        string QUERY;
       // OracleDataReader RDR;
        OracleDataAdapter da;
        DataSet d;

        public studentlog(string usr)
        {
            username = usr;
            InitializeComponent();
           CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");
            f1();
        }

        public void f1() {
            QUERY = "select * from studentlog";
            CMD = new OracleCommand(QUERY, CON1);
            try
            {
                CON1.Open();
                da = new OracleDataAdapter(QUERY, CON1);
                d = new DataSet();
                da.Fill(d, "test");
                dataGridView1.DataSource = d.Tables[0];
                CON1.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
            finally
            {
                CON1.Close();
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void studentlog_Load(object sender, EventArgs e)
        {
          
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            adminhome a = new adminhome(username);
            this.Hide();
            a.Show();
        }
    }
}
