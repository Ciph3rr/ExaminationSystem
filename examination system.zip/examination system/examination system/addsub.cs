﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace examination_system
{
    public partial class addsub : Form
    {
        int facid;
        string id;int subid;
        string QUERY; string name;
        OracleDataReader RDR;
        OracleConnection CON1;
        OracleCommand CMD;
        string username;
        public addsub(string usr)
        {
            InitializeComponent(); CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");NEWRECORD();
            username = usr;
            textBox3.Text =Convert.ToString(subid);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            addupdatefac AF = new addupdatefac(username);
            AF.Show();
        }
        public void NEWRECORD()
        {
      

            QUERY = "Select max(SUBJECTID) from SUBJECT";
            CON1.Open();
            CMD = new OracleCommand(QUERY,CON1);
            CMD.CommandText = QUERY;
            id = Convert.ToString(CMD.ExecuteScalar());
            if (id.Equals(""))
                subid = Convert.ToInt16(1);
            else
            {
                int s;
                s = Convert.ToInt16(id) + 1;
                subid = Convert.ToInt16(s);
            }
            CON1.Close();
            //MessageBox.Show(subid);
        }
        public void NEWRECORD1()
        {


            QUERY = "Select max(PROFID) from FACULTY";
            //CON1.Open();
        //    CMD = new OracleCommand(QUERY, CON1);
            CMD.CommandText = QUERY;
            id = Convert.ToString(CMD.ExecuteScalar());
            if (id.Equals(""))
                facid = Convert.ToInt16(1);
            else
            {
                int s;
                s = Convert.ToInt16(id) + 1;
               facid = Convert.ToInt16(s);
            }
            CON1.Close();
            //MessageBox.Show(subid);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            QUERY = "insert into SUBJECT values ('"+Convert.ToString(subid)+"','"+textBox2.Text+"','"+textBox1.Text+"')";
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();
            CMD.CommandType = CommandType.Text;int temp = 0;
            temp=CMD.ExecuteNonQuery();
            if(temp>0)
            {
                MessageBox.Show("success");
               // DateTime datetime = DateTime.Now;
               // string activity = "added a SUBJECT ('" + subid + "')";
 
                //    QUERY = "insert into adminlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "','" + textBox4.Text + "','" + textBox5.Text + "','" + subid + "')";
                CMD = new OracleCommand(QUERY, CON1);
                //CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("failure");
            }

            NEWRECORD1();
            QUERY = "insert into FACULTY values ('" +textBox2.Text+ "','" +textBox1.Text + "','" + facid + "')";
            MessageBox.Show(QUERY);
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();
            CMD.CommandType = CommandType.Text;
            int tempzz = 0;
           CMD.ExecuteNonQuery();
            if (tempzz > 0)
            {
                MessageBox.Show("success");
                DateTime datetime = DateTime.Now;
                string activity = "added a faculty ('" + facid + "')";

       QUERY = "CREATE TABLE  "+textBox1.Text+" (QUESTION VARCHAR2(200) NOT NULL ENABLE, OPTION1 VARCHAR2(200) NOT NULL ENABLE,OPTION2 VARCHAR2(200) NOT NULL ENABLE,OPTION3 VARCHAR2(200) NOT NULL ENABLE,CORRECT_OPTION VARCHAR2(200) NOT NULL ENABLE,QNO NUMBER,PRIMARY KEY(QNO) ENABLE)";
                CMD = new OracleCommand(QUERY, CON1);
                //CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
            MessageBox.Show("subject created");
            adminhome a = new adminhome(username);

            }
            else
            {
                MessageBox.Show("failure");
            }
            CON1.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
