﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
 
    public partial class findresult : Form
    {
        int id;
        int marks;
        string username, subject;
        OracleConnection CON1;
        OracleCommand CMD;
        string QUERY; OracleDataAdapter da;
        DataSet d;
        string name;
        OracleDataReader RDR;
        public findresult()
        {
            InitializeComponent();
            CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");
            LOADME();
        }
        public void LOADME()
        {
            QUERY = "select * from studentresults";
            CMD = new OracleCommand(QUERY, CON1);
            try
            {
                CON1.Open();
                da = new OracleDataAdapter(QUERY, CON1);
                d = new DataSet();
                da.Fill(d, "test");
                dataGridView1.DataSource = d.Tables[0];
                CON1.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
            finally
            {
                CON1.Close();
            }
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminhome ah = new adminhome(username);
            this.Hide();
            ah.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int flag = 0;
            QUERY = "select * from STUDENTRESULTS where SID='" + textBox1.Text + "'";
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();
            RDR = CMD.ExecuteReader();
            while (RDR.Read())
            {
                username = (string)RDR["USERNAME"];
                //id =(int)RDR["SID"];
                //               id = Convert.ToInt16(id1);
               marks= Convert.ToInt16(RDR["MARKS"]);
                subject = (string)RDR["SUBjECT"];
                flag = 1;
            }
            RDR.Close();
            CON1.Close();
            if(flag==1)
            {
                DateTime datetime = DateTime.Now;
                string activity = "Viewed results of student id (" + textBox1.Text + ")";
               // MessageBox.Show(username);
                QUERY = "insert into adminlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
                CMD = new OracleCommand(QUERY, CON1);
                CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
                CON1.Close();
                MessageBox.Show(" Username :  "+username+" Marks Obtained : "+marks+" Subject Answered : "+subject+"");

            }
            else
            {
                MessageBox.Show("incorrect sid");
            }
        }
    }
}
