﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
  public partial class loginpage : Form
    {
        int FLAG = 0;
        string pass = "";
        OracleConnection CON1;
        OracleCommand CMD;
        string QUERY;
        int TEMP;
        OracleDataReader RDR;

        string username ;
        public static string userid = "";

        public loginpage()
        {
            InitializeComponent();
            CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password=password ");
            // Calculate maximized location
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
       
        private void button3_Click(object sender, EventArgs e)
        {
         
            if (textBox2.Text == "" || maskedTextBox2.Text == "")
            {
                MessageBox.Show("Please enter all fields");
            }
            else
            {
                QUERY = "select * from ADMIN_LOGIN where username ='" + textBox2.Text + "' ";
                CMD = new OracleCommand(QUERY, CON1);
                CON1.Open();
                RDR = CMD.ExecuteReader();
                while (RDR.Read())
                {
                    pass = (string)RDR["password"];
                    FLAG = 1;
                }
                RDR.Close();
                CON1.Close();
                if (FLAG == 0)
                {
                    MessageBox.Show(" username doesnt exist");
                    textBox2.Text = "";
                    maskedTextBox2.Text = "";
                }
                else if (maskedTextBox2.Text == pass)
                {
                    username = maskedTextBox1.Text;
                    CON1.Open();
                    int temp = 0;
                    string activity = "logged in with username " + textBox1.Text + " ";
                    // QUERY = "INSERT INTO ADMINLOG VALUES =('" + textBox2.Text + "','" + DateTime.Now.ToLongTimeString() + "','" + activity + "' )";
                    DateTime datetime = DateTime.Now;
                    //  string activity = "added a question ('" + qno + "')";
                    //Addquestion();
                    QUERY = "insert into adminlog values  ('" + textBox2.Text + "','" + datetime.ToString() + "','" + activity + "')";
                    CMD = new OracleCommand(QUERY, CON1);
                    //CON1.Open();
                    CMD.CommandType = CommandType.Text;
                    CMD.ExecuteNonQuery();
                    CON1.Close();


                    adminhome ah = new adminhome(textBox2.Text);
                    this.Hide();
                    ah.Show();
                }
                else
                {
                    MessageBox.Show("Username and Password doesnt match.Please enter correct username and Password");
                    textBox2.Text = " ";
                    textBox2.Focus();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            username = textBox1.Text;
            FLAG = 0;
            if (textBox1.Text == "" || maskedTextBox1.Text == "")
            {
                MessageBox.Show("Please enter all fields");
            }
            else
            {
                QUERY = "select * from USER_LOGIN where username ='" + textBox1.Text + "' ";
                CMD = new OracleCommand(QUERY, CON1);
                CON1.Open();
                RDR = CMD.ExecuteReader();
                while (RDR.Read())
                {
                    pass = (string)RDR["password"];
                    FLAG = 1;
                }
                RDR.Close();
                CON1.Close();
                if (FLAG == 0)
                {
                    MessageBox.Show(" username doesnt exist");
                    textBox2.Text = "";
                    maskedTextBox2.Text = "";
                }
                else if (maskedTextBox1.Text == pass)
                {
                    CON1.Open();
                    int temp = 0;
                    string activity = "Admin logged in with username " + textBox1.Text + " ";
                    // QUERY = "INSERT INTO ADMINLOG VALUES =('" + textBox2.Text + "','" + DateTime.Now.ToLongTimeString() + "','" + activity + "' )";
                    DateTime datetime = DateTime.Now;
                    //  string activity = "added a question ('" + qno + "')";
                    //Addquestion();
                    QUERY = "insert into STUDENTLOG values  ('" + textBox1.Text + "','" + datetime.ToString() + "','" + activity + "')";
                    CMD = new OracleCommand(QUERY, CON1);
                    //CON1.Open();
                    CMD.CommandType = CommandType.Text;
                    CMD.ExecuteNonQuery();
                    CON1.Close();
                    username = textBox1.Text;
                    mainpage test = new mainpage(username);
                    this.Hide();
                    test.Show();
                }
                else
                {
                    MessageBox.Show("Username and Password doesnt match.Please enter correct username and Password");
                    textBox2.Text = " ";
                    textBox2.Focus();
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            register re = new register(username);
            this.Hide();
            re.Show();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
