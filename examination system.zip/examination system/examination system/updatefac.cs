﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace examination_system
{
    public partial class updatefac : Form
    {
        OracleDataReader RDR;
        OracleConnection CON1;
        OracleCommand CMD;
        string QUERY;
        OracleDataAdapter da;
        DataSet d;
        string username;
        public updatefac(string usr)
        {
            InitializeComponent(); CON1 = new OracleConnection("Data Source=XE;User ID=dbms;password= password ");
            loader();
            username = usr;
        }
        public void loader()
        {
            QUERY = "select * from  FACULTY ";
            CMD = new OracleCommand(QUERY, CON1);
            try
            {
                CON1.Open();
                da = new OracleDataAdapter(QUERY, CON1);
                d = new DataSet();
                da.Fill(d, "test");
                dataGridView1.DataSource = d.Tables[0];
                CON1.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
            finally
            {
                CON1.Close();
            }
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            QUERY = "update FACULTY set PROFNAME='" + textBox4.Text + "',SUBJECTTHOUGHT='" + textBox2.Text + "' where PROFID=" + textBox1.Text + " ";
            CMD = new OracleCommand(QUERY, CON1);
            CON1.Open();
            int temp = 0;
            CMD.CommandType = CommandType.Text;
            temp = CMD.ExecuteNonQuery();
            if (temp > 0)
            {
                MessageBox.Show("updated!!");

                DateTime datetime = DateTime.Now;
                string activity = ""+username+"UPDATED FACULTY DETAILS  TO  PROF NAME: (" + textBox4.Text+ ") AND SUBJECT THOUGHT TO : " +textBox2.Text + "";
               // Addquestion();
                QUERY = "insert into adminlog values  ('" + username + "','" + datetime.ToString() + "','" + activity + "')";
                CMD = new OracleCommand(QUERY, CON1);
               // CON1.Open();
                CMD.CommandType = CommandType.Text;
                CMD.ExecuteNonQuery();
               // CON1.Close();
            }
            else
            {
                MessageBox.Show("error");
            }
            CON1.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            loader();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminhome ah = new adminhome(username);
            this.Hide();
            ah.Show();
        }
    }
}
